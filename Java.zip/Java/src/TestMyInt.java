import org.junit.Test;

import static org.junit.Assert.*;

public class TestMyInt {

    @Test
    public void testAdd() throws Exception{
        MyInt a = new MyInt(new byte[]{0, 3});
        MyInt b = new MyInt("-2");
        String result = "1";

        assertEquals(result, a.add(b).toString());
    }

    @Test
    public void testSubtract() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "1";

        assertEquals(result, a.subtract(b).toString());
    }

    @Test
    public void testMultiplyPositive() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "6";

        assertEquals(result, a.multiply(b).toString());
    }

    @Test
    public void testMultiplyNegative() throws Exception{
        MyInt a = new MyInt(-3);
        MyInt b = new MyInt(2);
        String result = "-6";

        assertEquals(result, a.multiply(b).toString());
    }

    @Test
    public void testAbsPositive() throws Exception{
        MyInt a = new MyInt(3);
        String result = "3";

        assertEquals(result, a.abs().toString());
    }

    @Test
    public void testAbsNegative() throws Exception{
        MyInt a = new MyInt(-3);
        String result = "3";

        assertEquals(result, a.abs().toString());
    }

    @Test
    public void testCompareToTrue() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(3);

        assertTrue(a.compareTo(b));
    }

    @Test
    public void testCompareToFalse() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);

        assertFalse(a.compareTo(b));
    }
/*МОГУТ ИЗМЕНЯТЬСЯ*/
    @Test
    public void testDivideInteger() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(1);
        String result = "3";

        assertEquals(result, a.divide(b).toString());
    }

    @Test
    public void testDivideNotinteger() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "1";

        assertEquals(result, a.divide(b).toString());
    }

    @Test
    public void testGcd() throws Exception{
        MyInt a = new MyInt(10);
        MyInt b = new MyInt(5);
        String result = "5";

        assertEquals(result, a.gcd(b).toString());
    }

    @Test
    public void testMax() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "3";

        assertEquals(result, a.max(b).toString());
    }

    @Test
    public void testMin() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "2";

        assertEquals(result, a.min(b).toString());
    }

    @Test
    public void testLongValue() throws Exception{
        MyInt a = new MyInt(3);
        long result = 3;

        assertEquals(result, a.longValue());
    }
}
