import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class TestMyInt {

    @Test
    public void testAdd() throws Exception{
        MyInt a = new MyInt(new byte[]{0, 3});
        MyInt b = new MyInt("-2");
        String result = "1";

        assertEquals(result, a.add(b).toString());
    }

    @Test
    public void testSubtract() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "1";

        assertEquals(result, a.subtract(b).toString());
    }

    @Test
    public void testMax() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        String result = "3";

        assertEquals(result, a.max(b).toString());
    }

    @Test
    public void testLongValue() throws Exception{
        MyInt a = new MyInt(3);
        long result = 3;

        assertEquals(result, a.longValue());
    }
}
