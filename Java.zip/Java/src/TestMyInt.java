import org.junit.Test;

public class TestMyInt {

    @Test
    public void testAdd() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        MyInt c = a.add(b);
    }

    @Test
    public void testMax() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);
        MyInt c = a.add(b);
        MyInt max = c.max(a);
    }

    @Test
    public void testLongValue() throws Exception{
        MyInt a = new MyInt(3);
        MyInt b = new MyInt("2");
        MyInt c = a.add(b);
        long d = c.longValue();
    }
}
