import org.junit.Test;

import static org.junit.Assert.*;

public class TestDEQueue {

    @Test
    public void testPushBack() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        String result = "1234";
        assertEquals(result, queue.toString());
    }

    @Test
    public void testPushFront() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushFront(1);
        queue.pushFront(2);
        queue.pushFront(3);
        queue.pushFront(4);

        String result = "4321";
        assertEquals(result, queue.toString());
    }

    @Test(expected = NullPointerException.class)
    public void testPopFrontEmpty() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.popFront();
    }
    @Test
    public void testPopFront() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        int resultPop = 1;
        String result = "234";
        assertTrue(resultPop == queue.popFront());
        assertEquals(result, queue.toString());
    }

    @Test(expected = NullPointerException.class)
    public void testPopBackEmpty() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.popBack();
    }
    @Test
    public void testPopBack() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        int resultPop = 4;
        String result = "123";
        assertTrue(resultPop == queue.popBack());
        assertEquals(result, queue.toString());
    }

    @Test(expected = NullPointerException.class)
    public void testBackEmpty() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.back();
    }
    @Test
    public void testBack() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        int result = 4;
        assertTrue(result == queue.back());
    }

    @Test(expected = NullPointerException.class)
    public void testFrontEmpty() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.front();
    }
    @Test
    public void testFront() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        int result = 1;
        assertTrue(result == queue.front());
    }

    @Test
    public void testSize() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        int result = 4;
        assertEquals(result, queue.size());
    }

    @Test
    public void testClear() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);
        queue.clear();

        String result = "";
        assertEquals(result, queue.toString());
    }

    @Test
    public void testToArrayEmpty() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();

        assertNull("Empty massive", queue.toArray());
    }

    @Test
    public void testToArray() throws Exception{
        DEQueue<Integer> queue = new DEQueue<Integer>();
        boolean result = true;

        queue.pushBack(1);
        queue.pushBack(2);
        queue.pushBack(3);
        queue.pushBack(4);

        String[] resList = {"1", "2", "3", "4"};
        String[] list = queue.toArray();

        if(list.length != resList.length)
            result = false;
        else
            for(int i = 0; i < list.length; i++){
                if(!list[i].equals(resList[i])){
                    result = false;
                    break;
                }
            }

        assertTrue(result);
    }

}
