public final class MyInt {
    private StringBuilder number;

    //constructors
    public MyInt(){
        this.number = new StringBuilder();
    }
    public MyInt(long number) {
        this();
        this.number.append(number);
    }

    public MyInt(String number) {
        this();
        this.number.append(number);
    }

    public MyInt(byte[] number) {
        this();

        if (number[0] == 1)
            this.number.append("-");

        for (int i = 1; i < number.length; i++){
            this.number.append(number[i]);
        }
    }

    //methods
    /*сложение*/
    public MyInt add(MyInt num){
        long result = this.longValue()
                     + num.longValue();
        return new MyInt(result);
    }

    /*вычитание*/
    public MyInt subtract(MyInt num){
        long result = this.longValue()
                     - num.longValue();
        return new MyInt(result);
    }
    /*умножене*/
    public MyInt multiply(MyInt num){
        long result = this.longValue()
                        * num.longValue();
        return new MyInt(result);
    }
    /*максимум*/
    public MyInt max(MyInt num){
        boolean condition = this.longValue() >=
                            num.longValue();

        if (condition)
            return new MyInt(this.toString());
        else
            return num;
    }
    /*минимум*/
    public MyInt min(MyInt num){
        boolean condition = this.longValue() <=
                num.longValue();

        if (condition)
            return new MyInt(this.toString());
        else
            return num;
    }
    /*абсолютное значение*/
    public MyInt abs(){
        if (this.longValue() < 0)
            return new MyInt(this.toString().substring(1));
        else
            return new MyInt(this.toString());
    }
    /*сравнение*/
    public boolean compareTo(MyInt num){
        return this.toString().equals(num.toString());
    }

    public MyInt divide(MyInt num){
        long x = this.longValue();
        long y = num.longValue();
        if (y == 0) throw new ArithmeticException();

        int sign = ((x < 0) ^ (y < 0)) ? -1 : 1;

        x = Math.abs(x);
        y = Math.abs(y);
        long quotient = 0;

        while (x >= y)
        {
            x -= y;
            ++quotient;
        }

        return new MyInt(sign * quotient);
    }

    public MyInt gcd(MyInt num){
        long x = this.longValue();
        long y = num.longValue();

        if (y != 0)
        {
            while (x != y)
            {
                if (x > y)
                    x -= y;
                else
                    y -= x;
            }
        }

        return new MyInt(x);
    }



    /*преобразование в строку*/
    public String toString() {
        return this.number.toString();
    }

    /*преобразование в целый тип long*/
    public long longValue(){
        return Long.parseLong(this.toString());
    }
}
