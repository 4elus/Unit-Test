public final class MyInt {

    private int number;


    public MyInt(int number) {
        this.number = number;
    }

    public MyInt(String number) {
        this.number = Integer.parseInt(number);
    }


    public MyInt add(MyInt num){
        return new MyInt(number + num.number);
    }

    public MyInt max(MyInt num){
        return (number > num.number) ? new MyInt(number) : new MyInt(number);
    }


    public String toString() {
        return String.valueOf(this.number);
    }

    public long longValue(){
        return Long.parseLong(String.valueOf(this.number));
    }
}
