public final class MyInt {
    private StringBuilder number;

    //constructors
    public MyInt(){
        this.number = new StringBuilder();
    }
    public MyInt(int number) {
        this();
        this.number.append(number);
    }

    public MyInt(String number) {
        this();
        this.number.append(number);
    }

    public MyInt(byte[] number) {
        this();

        if (number[0] == 1)
            this.number.append("-");

        for (int i = 1; i < number.length; i++){
            this.number.append(number[i]);
        }
    }

    //methods
    /*сложение*/
    public MyInt add(MyInt num){
        int result = Integer.parseInt(this.toString())
                     + Integer.parseInt(num.toString());
        return new MyInt(result);
    }

    /*вычитание*/
    public MyInt subtract(MyInt num){
        int result = Integer.parseInt(this.toString())
                     - Integer.parseInt(num.toString());
        return new MyInt(result);
    }

    /*максимум*/
    public MyInt max(MyInt num){
        boolean condition = Integer.parseInt(this.toString()) >=
                            Integer.parseInt(num.toString());

        if (condition)
            return new MyInt(this.toString());
        else
            return num;
    }

    /*преобразование в строку*/
    public String toString() {
        return this.number.toString();
    }

    /*преобразование в целый тип long*/
    public long longValue(){
        return Long.parseLong(this.toString());
    }
}
