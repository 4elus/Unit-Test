public final class MyInt {
    private StringBuilder number;

    //constructors
    public MyInt(){
        this.number = new StringBuilder();
    }
    public MyInt(long number) {
        this();
        this.number.append(number);
    }

    public MyInt(String number) {
        this();
        this.number.append(number);
    }

    public MyInt(byte[] number) {
        this();

        if (number[0] == 1)
            this.number.append("-");

        for (int i = 1; i < number.length; i++){
            this.number.append(number[i]);
        }
    }

    //methods
    /*сложение*/
    public MyInt add(MyInt num){
        long result = this.longValue()
                     + num.longValue();
        return new MyInt(result);
    }

    /*вычитание*/
    public MyInt subtract(MyInt num){
        long result = this.longValue()
                     - num.longValue();
        return new MyInt(result);
    }
    /*умножене*/
    public MyInt multiply(MyInt num){
        long result = this.longValue()
                        * num.longValue();
        return new MyInt(result);
    }
    /*максимум*/
    public MyInt max(MyInt num){
        boolean condition = this.longValue() >=
                            num.longValue();

        if (condition)
            return new MyInt(this.toString());
        else
            return num;
    }
    /*минимум*/
    public MyInt min(MyInt num){
        boolean condition = this.longValue() <=
                num.longValue();

        if (condition)
            return new MyInt(this.toString());
        else
            return num;
    }
    /*абсолютное значение*/
    public MyInt abs(){
        if (this.longValue() < 0)
            return new MyInt(this.toString().substring(1));
        else
            return new MyInt(this.toString());
    }
    /*сравнение*/
    public boolean compareTo(MyInt num){
        return this.toString().equals(num.toString());
    }
    //реализовать надо
    public MyInt divide(MyInt num){
        return new MyInt(0);
    }
    //тоже надо реализовать))))00))))0)))0)0
    public MyInt gcd(MyInt num){
        return new MyInt(0);
    }

    /*преобразование в строку*/
    public String toString() {
        return this.number.toString();
    }

    /*преобразование в целый тип long*/
    public long longValue(){
        return Long.parseLong(this.toString());
    }
}
