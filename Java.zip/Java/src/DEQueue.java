import java.util.ArrayList;

public class DEQueue<T> implements Iterable<T>{
    private int size = 0;
    private Node<T> head = null;
    private Node<T> tail = null;

    @Override
    public java.util.Iterator<T> iterator() {
        return new java.util.Iterator<T>() {
            private Node<T> trav = head;

            @Override
            public boolean hasNext() {
                return trav.next != null;
            }

            @Override
            public T next() {
                T data = trav.data;
                trav = trav.next;
                return data;
            }

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }
        };
    }

    private static class Node<T> {
        private T data;
        private Node<T> prev, next;

        public Node(T data, Node<T> prev, Node<T> next) {
            this.data = data;
            this.prev = prev;
            this.next = next;
        }

        @Override
        public String toString() {
            return data.toString();
        }
    }


    public boolean isEmpty() {
        return size() == 0;
    }

    public void pushBack(T elem) {
        if (isEmpty()) {
            head = tail = new Node<T>(elem, null, null);
        } else {
            tail.next = new Node<T>(elem, tail, null);
            tail = tail.next;
        }
        size++;
    }

    public void pushFront(T elem) {
        if (isEmpty()) {
            head = tail = new Node<T>(elem, null, null);
        } else {
            head.prev = new Node<T>(elem, null, head);
            head = head.prev;
        }
        size++;
    }

    public T popBack()
    {
        T data = tail.data;

        size --;
        if (size()==0)
            head = tail = null;
        else
        {
            tail = tail.prev;
            tail.next = null;
        }

        return data;
    }

    public T popFront()
    {
        T data = head.data;

        size --;
        if (size()==0)
            head = tail = null;
        else
        {
            head = head.next;
            head.prev = null;
        }

        return data;
    }

    public T front() {
        return head.data;
    }

    public T back() {
        return tail.data;
    }

    public void clear() {
        Node<T> trav = head;
        while (trav != null) {
            Node<T> next = trav.next;
            trav.prev = trav.next = null;
            trav.data = null;
            trav = next;
        }
        head = tail = null;
        size = 0;
    }

    public int size() {
        return size;
    }

    public String[] toArray() {
        String[] massive = new String[size()];
        Node<T> trav = head;
        int index = 0;
        while (trav != null) {
            massive[index] = trav.data.toString();
            trav = trav.next;
            index++;
        }

        if (massive.length == 0)
            return null;
        return massive;
    }

    public String toString()
    {
        StringBuilder sb = new StringBuilder("");
        Node<T> trav = head;
        while (trav != null) {
            sb.append(trav.data);
            trav = trav.next;
        }

        return sb.toString();
    }
}
