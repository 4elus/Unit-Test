import org.junit.Test;

public class Runner {
    public static void main(String[] args) {
        MyInt a = new MyInt(3);
        MyInt b = new MyInt(2);

        MyInt c = a.add(b);
        MyInt max = c.max(a);
        System.out.println(max);
        long d = c.longValue();
        System.out.println(d);

    }
}
