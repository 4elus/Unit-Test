import org.junit.Test;

import java.util.Arrays;

public class Runner {
    public static void main(String[] args) {
        /*DEQueue<Integer> queue = new DEQueue<Integer>();
        queue.pushFront(2);
        queue.pushFront(1);
        System.out.println(Arrays.toString(queue.toArray()));*/



        MyInt myInt = new MyInt(32);
        MyInt myInt1 = new MyInt(4);
        MyInt myInt2 = myInt.gcd(myInt1);

        System.out.println(myInt2.toString());
    }
}
