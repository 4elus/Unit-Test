import org.junit.Test;

public class Runner {
    public static void main(String[] args) {
        DEQueue<Integer> queue = new DEQueue<Integer>();

        System.out.println(queue.toString());
    }
}
