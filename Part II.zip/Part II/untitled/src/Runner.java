public class Runner {
    public static void main(String[] args) {
        Dequeue list = new Dequeue();

        //list.pushBack("Java");
        list.pushFront("Python");
        list.pushFront(1);
        System.out.println(list.toArray());

    }
}
